package cz.educanet;

public class Main {
}
